import { test, expect, Page } from "@playwright/test";


test('Datepicker handling', async ({ page }) => {

    await page.goto("https://www.delta.com/apac/en");

    await page.getByLabel('BLR').click();

    await page.locator('span.predictive-search__wrapper--cancel-icon').click();

    await page.locator('#predictive_search_k2un7z9kush').fill('BLR');

    await page.locator('span.predictive-search__wrapper--cancel-icon').click();


    await page.waitForTimeout(2000);
})
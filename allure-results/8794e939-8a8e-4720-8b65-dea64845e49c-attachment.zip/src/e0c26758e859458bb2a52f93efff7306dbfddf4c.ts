import { test, expect, Page } from "@playwright/test";

/**
 * Dynamically selects a date on the Delta.com date picker calendar.
 * Navigates forward month-by-month until the target month/year is visible,
 * then clicks the target day.
 */
async function selectDateFromPicker(
  page: Page,
  targetDate: Date
) {
  const targetMonth = targetDate.toLocaleString("en-US", { month: "long" }); // e.g. "December"
  const targetYear = targetDate.getFullYear().toString();                    // e.g. "2026"
  const targetDay = targetDate.getDate().toString();                         // e.g. "25"

  // Keep clicking the "next month" arrow until the calendar header shows the target month/year
  const calendarHeader = page.locator(".monthYear");
  const nextMonthBtn = page.locator('button[aria-label="Next Month"]');

  // Safety limit to avoid infinite loops (max 12 months forward)
  for (let attempt = 0; attempt < 12; attempt++) {
    const headerText = await calendarHeader.first().textContent();
    if (headerText?.includes(targetMonth) && headerText?.includes(targetYear)) {
      break;
    }
    await nextMonthBtn.click();
  }

  // Click the specific day within the target month's grid
  // Delta renders each day as an aria-label like "25 December 2026"
  const dayLabel = `${targetDay} ${targetMonth} ${targetYear}`;
  await page.getByLabel(dayLabel, { exact: true }).click();
}

test.describe("Delta.com Date Picker", () => {

  test.beforeEach(async ({ page }) => {
    await page.goto("https://www.delta.com/apac/en");
  });

  test("should dynamically select a future departure and return date", async ({ page }) => {

    // --- Step 1: Set Origin (From) ---
    const originField = page.getByRole("combobox", { name: /origin/i }).or(
      page.locator("#search_input_origin")
    );
    await originField.click();
    // Clear any pre-filled value and type the new origin
    await originField.fill("BLR");
    await page.getByText("BLR Bengaluru, India").click();

    // --- Step 2: Set Destination (To) ---
    const destinationField = page.getByRole("combobox", { name: /destination/i }).or(
      page.locator("#search_input_destination")
    );
    await destinationField.click();
    await destinationField.fill("MAA");
    await page.getByText("MAA Chennai, India").click();

    // --- Step 3: Dynamically compute target dates ---
    const today = new Date();
    const departureDate = new Date(today);
    departureDate.setDate(today.getDate() + 7); // 1 week from today

    const returnDate = new Date(departureDate);
    returnDate.setDate(departureDate.getDate() + 5); // 5 days after departure

    // --- Step 4: Open date picker and select departure date ---
    const datePickerTrigger = page.locator('[aria-label="Depart Date Calendar"]').or(
      page.locator('[data-testid="date-picker-depart"]')
    ).or(page.getByRole("button", { name: /depart/i }));
    await datePickerTrigger.click();

    await selectDateFromPicker(page, departureDate);

    // --- Step 5: Select return date (calendar typically stays open after departure selection) ---
    await selectDateFromPicker(page, returnDate);

    // --- Step 6: Assertions ---
    const departureDayFormatted = departureDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    }); // e.g. "Oct 1"

    const returnDayFormatted = returnDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    }); // e.g. "Oct 6"

    // Verify the selected dates are reflected in the input fields
    await expect(
      page.locator('[data-testid="depart-date"]').or(page.getByText(departureDayFormatted).first())
    ).toBeVisible();
    await expect(
      page.locator('[data-testid="return-date"]').or(page.getByText(returnDayFormatted).first())
    ).toBeVisible();
  });
});